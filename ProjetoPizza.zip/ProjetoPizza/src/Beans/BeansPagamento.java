/*
 *declaração de atributos
 */
package Beans;

/**
 *
 * @author cb
 */
public class BeansPagamento {
    private String card;
    private String money;

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }
    
    
}
